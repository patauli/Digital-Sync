
import React, { useState } from 'react';
import axios from 'axios';

export default function App() {
  const [url, setUrl] = useState('');
  const [report, setReport] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleAnalyze = async () => {
    setLoading(true);
    setReport(null);
    setError(null);
    try {
      const res = await axios.post('/analyze', { url });
      setReport(res.data);
    } catch (err) {
      console.error(err);
      setError('Failed to analyze site. Please ensure the backend is running and CORS is configured.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 p-8">
      <div className="max-w-xl mx-auto bg-white p-6 rounded-xl shadow-md">
        <h1 className="text-2xl font-bold mb-4">Free SEO Report Tool</h1>
        <input
          type="text"
          placeholder="Enter website URL (e.g., https://example.com)"
          className="w-full p-2 border rounded mb-4"
          value={url}
          onChange={(e) => setUrl(e.target.value)}
        />
        <button
          onClick={handleAnalyze}
          className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
          disabled={loading || !url}
        >
          {loading ? 'Analyzing...' : 'Generate Report'}
        </button>

        {error && (
          <p className="text-red-600 mt-4">{error}</p>
        )}

        {report && (
          <div className="mt-6">
            <h2 className="text-xl font-semibold mb-2">SEO Report:</h2>
            <p><strong>Title:</strong> {report.title}</p>
            <p><strong>Meta Description:</strong> {report.metaDescription}</p>
            <p><strong>H1:</strong> {report.h1}</p>
            <p><strong>Word Count:</strong> {report.wordCount}</p>
            <p><strong>HTTPS:</strong> {report.https ? 'Yes' : 'No'}</p>
            <p><strong>PageSpeed Score:</strong> {report.speedScore}</p>
          </div>
        )}
      </div>
    </div>
  );
}
