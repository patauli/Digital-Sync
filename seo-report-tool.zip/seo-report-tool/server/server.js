
const express = require('express');
const cors = require('cors');
const axios = require('axios');
const cheerio = require('cheerio');

const app = express();
app.use(cors());
app.use(express.json());

app.post('/analyze', async (req, res) => {
  const { url } = req.body;

  try {
    const { data: html } = await axios.get(url);
    const $ = cheerio.load(html);

    const title = $('title').text() || 'N/A';
    const metaDescription = $('meta[name="description"]').attr('content') || 'N/A';
    const h1 = $('h1').first().text() || 'N/A';
    const wordCount = $('body').text().split(/\s+/).filter(Boolean).length;
    const https = url.startsWith('https');

    const psiRes = await axios.get(
      `https://www.googleapis.com/pagespeedonline/v5/runPagespeed?url=${encodeURIComponent(
        url
      )}&category=performance`
    );
    const speedScore = psiRes.data.lighthouseResult.categories.performance.score * 100;

    res.json({ title, metaDescription, h1, wordCount, https, speedScore });
  } catch (error) {
    console.error('Error fetching/analyzing site:', error);
    res.status(500).json({ error: 'Failed to analyze site' });
  }
});

app.listen(5000, () => {
  console.log('SEO Report server running on http://localhost:5000');
});
