
# SEO Report Tool

A fullstack tool that lets users input a website URL and receive basic SEO and speed audit reports. Built with React (frontend) and Node.js (backend), using Google PageSpeed API and cheerio for scraping.

## 🚀 Features
- Title, Meta Description, H1 tag detection
- Word count & HTTPS check
- PageSpeed score via Google API
- React frontend + Node.js API backend
- Proxy setup for smooth dev experience

## 🛠 How to Run

```bash
npm install          # from root
npm run dev          # starts both frontend & backend
```

## 📁 Structure

- `/client` - React app
- `/server` - Node Express API
